To integrate the voice ads copy the files from the archive into the libs/ folder of your project.

NOTE: If you do not want to to include voice ads within you application, only copy the millinnial sdk to your libs/ directory.

Add the following permissions to your AndroidManifest.xml

<uses-feature android:name="android.hardware.microphone" android:required="false" />
<uses-permission android:name="android.permission.RECORD_AUDIO" />

NOTE: The microphone uses-feature element and the record audio permission are only required if including voice ads within you application.